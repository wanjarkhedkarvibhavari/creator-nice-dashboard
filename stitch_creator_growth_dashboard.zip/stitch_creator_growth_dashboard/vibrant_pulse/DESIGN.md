---
name: Vibrant Pulse
colors:
  surface: '#0b1326'
  surface-dim: '#0b1326'
  surface-bright: '#31394d'
  surface-container-lowest: '#060e20'
  surface-container-low: '#131b2e'
  surface-container: '#171f33'
  surface-container-high: '#222a3d'
  surface-container-highest: '#2d3449'
  on-surface: '#dae2fd'
  on-surface-variant: '#c7c4d7'
  inverse-surface: '#dae2fd'
  inverse-on-surface: '#283044'
  outline: '#908fa0'
  outline-variant: '#464554'
  surface-tint: '#c0c1ff'
  primary: '#c0c1ff'
  on-primary: '#1000a9'
  primary-container: '#8083ff'
  on-primary-container: '#0d0096'
  inverse-primary: '#494bd6'
  secondary: '#4edea3'
  on-secondary: '#003824'
  secondary-container: '#00a572'
  on-secondary-container: '#00311f'
  tertiary: '#ffb95f'
  on-tertiary: '#472a00'
  tertiary-container: '#ca8100'
  on-tertiary-container: '#3e2400'
  error: '#ffb4ab'
  on-error: '#690005'
  error-container: '#93000a'
  on-error-container: '#ffdad6'
  primary-fixed: '#e1e0ff'
  primary-fixed-dim: '#c0c1ff'
  on-primary-fixed: '#07006c'
  on-primary-fixed-variant: '#2f2ebe'
  secondary-fixed: '#6ffbbe'
  secondary-fixed-dim: '#4edea3'
  on-secondary-fixed: '#002113'
  on-secondary-fixed-variant: '#005236'
  tertiary-fixed: '#ffddb8'
  tertiary-fixed-dim: '#ffb95f'
  on-tertiary-fixed: '#2a1700'
  on-tertiary-fixed-variant: '#653e00'
  background: '#0b1326'
  on-background: '#dae2fd'
  surface-variant: '#2d3449'
typography:
  headline-xl:
    fontFamily: Plus Jakarta Sans
    fontSize: 40px
    fontWeight: '800'
    lineHeight: 48px
    letterSpacing: -0.02em
  headline-xl-mobile:
    fontFamily: Plus Jakarta Sans
    fontSize: 30px
    fontWeight: '800'
    lineHeight: 38px
    letterSpacing: -0.02em
  headline-lg:
    fontFamily: Plus Jakarta Sans
    fontSize: 28px
    fontWeight: '700'
    lineHeight: 36px
    letterSpacing: -0.015em
  headline-lg-mobile:
    fontFamily: Plus Jakarta Sans
    fontSize: 22px
    fontWeight: '700'
    lineHeight: 30px
    letterSpacing: -0.015em
  headline-md:
    fontFamily: Plus Jakarta Sans
    fontSize: 20px
    fontWeight: '600'
    lineHeight: 28px
    letterSpacing: -0.01em
  body-lg:
    fontFamily: Inter
    fontSize: 16px
    fontWeight: '400'
    lineHeight: 24px
  body-md:
    fontFamily: Inter
    fontSize: 14px
    fontWeight: '400'
    lineHeight: 20px
  body-sm:
    fontFamily: Inter
    fontSize: 12px
    fontWeight: '400'
    lineHeight: 16px
  label-lg:
    fontFamily: Inter
    fontSize: 14px
    fontWeight: '600'
    lineHeight: 20px
    letterSpacing: 0.01em
  label-md:
    fontFamily: Inter
    fontSize: 12px
    fontWeight: '600'
    lineHeight: 16px
    letterSpacing: 0.02em
  label-sm:
    fontFamily: Inter
    fontSize: 11px
    fontWeight: '600'
    lineHeight: 14px
    letterSpacing: 0.04em
rounded:
  sm: 0.25rem
  DEFAULT: 0.5rem
  md: 0.75rem
  lg: 1rem
  xl: 1.5rem
  full: 9999px
spacing:
  gutter: 1.5rem
  gutter-mobile: 0.75rem
  margin: 2rem
  margin-mobile: 1rem
  space-xs: 0.25rem
  space-sm: 0.5rem
  space-md: 1rem
  space-lg: 1.5rem
  space-xl: 2.5rem
---

## Brand & Style

This design system targets digital creators, solopreneurs, and agile media operators managing multi-channel content workflows. The brand posture balances operational precision with high-velocity creative energy. It eliminates bureaucratic clutter while prioritizing real-time analytics, instant metric validation, and editorial velocity.

The aesthetic blends sleek Modern Minimalism with selective Glassmorphic depth and tactical high-contrast data visualization. Surfaces leverage deep slate tones punctuated by electric chromatic accents, giving data visualizations an luminous, focused impact. High typographic contrast ensures that dense engagement dashboards remain scannable during rapid publishing, performance triage, and revenue tracking workflows.

## Colors

The palette utilizes a deep slate foundation to reduce visual fatigue during prolonged content production and data analysis. 

- **Primary (`#6366F1` / `#4F46E5`):** High-energy violet-indigo dedicated to primary workflows, interactive elements, primary metrics, and focal action triggers.
- **Secondary (`#10B981`):** Precision emerald green signaling positive delta metrics, active engagement gains, published content states, and revenue growth.
- **Tertiary (`#F59E0B`):** Warm electric amber used for scheduled queues, pending approvals, velocity warnings, and monetization thresholds.
- **Neutral Foundation (`#0F172A`, `#1E293B`, `#334155`, `#F8FAFC`):** Deep charcoal slate backdrop (`#0F172A`) paired with elevated container slates (`#1E293B`, `#334155`) for structural hierarchy, finished with ultra-crisp slate white (`#F8FAFC`) for primary text legibility.
- **Channel Specifics:** Dedicated brand tokens for channel identifiers remain untouched: LinkedIn (`#0A66C2`), YouTube Shorts (`#FF0000`), X (`#F8FAFC` on `#0F1419`), and Instagram (linear gradient: `#833AB4` to `#FD1D1D` to `#FCB045`).

## Typography

Typography balances structural personality with rigorous data readability. 

Plus Jakarta Sans provides high-impact geometric architecture for headings, revenue figures, and headline analytics. Its modern proportions inject optimistic, executive energy into dashboards. 

Inter handles high-density data, metadata labels, tabular metrics, and form fields. It provides neutral clarity with optimized glyph legibility across micro-sizes. Tabular figures must be enabled for all metric components, performance indicators, and timestamp monitors to prevent UI jitter during real-time data streaming.

## Layout & Spacing

The dashboard operates on a 12-column responsive fluid grid anchored by strict 8px/4px spatial intervals.

- **Desktop (1280px+):** 12-column layout with 2rem outer canvas margins and 1.5rem gutters. Side navigation remains persistent (260px fixed width), while analytical widgets collapse or stretch across standard 3, 4, 6, or 12 column cards.
- **Tablet (768px - 1279px):** 8-column layout with 1.5rem margins and 1rem gutters. Side navigation collapses to an icon bar or overlay menu; multi-stat row cards reflow into 2x2 grids.
- **Mobile (< 768px):** 4-column layout with 1rem canvas margins and 0.75rem gutters. Metric tiles stack vertically or swipe horizontally inside smooth scrollable carousels.

Component interiors enforce rigorous padding rules: `space-lg` (1.5rem) for card envelopes, `space-md` (1rem) for action bars, and `space-sm` (0.5rem) for metadata badge clusters.

## Elevation & Depth

Visual hierarchy relies on subtle glassmorphic translucency layered over deep slate, paired with fine micro-borders and localized ambient glows.

- **Level 0 (Canvas Base):** Solid background at `#0F172A`.
- **Level 1 (Surface Containers / Cards):** Semi-transparent `#1E293B` at 75% opacity with `backdrop-filter: blur(12px)`. Enclosed by a 1px ghost border using `#334155` at 40% opacity. Shadows are omitted in favor of contrast borders, keeping the aesthetic crisp and modern.
- **Level 2 (Hover States & Active Cards):** Surface `#1E293B` at 90% opacity, bordered by `#6366F1` at 35% opacity, with a soft diffused ambient glow: `box-shadow: 0 8px 24px -4px rgba(99, 102, 241, 0.12)`.
- **Level 3 (Modals, Overlays, Floating Menus):** High-density `#1E293B` at 98% opacity with a multi-layered drop shadow: `0 20px 25px -5px rgba(0, 0, 0, 0.5), 0 8px 10px -6px rgba(0, 0, 0, 0.5)` alongside a 1px border of `#475569` at 60% opacity.

## Shapes

The design system utilizes consistent geometric shaping based on roundedness level 2 (0.5rem base radius). 

Standard interactive elements—such as input fields, buttons, and dropdown triggers—use 0.5rem (`8px`). Metric cards, dashboard modular containers, and workflow panels use `rounded-lg` (1rem / `16px`). High-visibility modal dialogs and slide-out trays employ `rounded-xl` (1.5rem / `24px`). Status pills, avatar wrappers, and channel identifiers strictly leverage full pill shapes (`9999px`) to create clear geometric contrast against angular data containers.

## Components

### Buttons
- **Primary:** Solid `#6366F1` background with white text, transitioning to `#4F46E5` on hover. 0.5rem border radius, height 40px, medium weight type. Features a subtle inner top highlight (`box-shadow: inset 0 1px 0 rgba(255, 255, 255, 0.2)`).
- **Secondary:** Semi-transparent slate (`#334155` at 40%) with a 1px border (`#475569`), shifting to 70% opacity on hover.
- **Destructive/Critical:** Soft rose background (`#EF4444` at 15%) paired with bright crimson text (`#F87171`) and a 1px outline (`#EF4444` at 30%).

### Platform Badges & Chips
- **Structure:** Pill-shaped (`9999px`) micro-containers (height 24px) pairing platform brand colors with crisp labels.
- **Platform Variants:**
  - *LinkedIn:* Solid `#0A66C2` glyph inside a 12% tint container.
  - *YouTube Shorts:* Crimson `#FF0000` glyph inside a 12% tint container.
  - *Instagram:* 1.5px gradient border with an internal `#833AB4` to `#FD1D1D` brand icon.
  - *X:* Pure white icon over `#000000` fill with a subtle `#334155` border.
- **Metric Status Chips:** Emerald green (`#10B981` at 15% fill, `#10B981` text) for positive deltas (`+18.4%`), amber (`#F59E0B`) for plateau/pending alerts.

### Cards & Analytical Widgets
Containers feature 1rem roundedness, glassmorphic backdrop blur (12px), 1px slate ghost border, and internal padding of 1.5rem. Metric cards feature a headline stat in Plus Jakarta Sans, an inline trending indicator chip, and a contextual channel badge in the upper right corner.

### Form Inputs & Checkboxes
- **Inputs:** Dark field surface (`#0F172A` at 60%), 1px slate-600 border, 0.5rem radius, height 42px. Focus rings use a sharp 2px electric violet ring (`#6366F1`) with 2px offset.
- **Checkboxes & Radios:** 0.5rem or fully circular shapes with a 1.5px border (`#475569`). Selected state fills with solid `#6366F1` and a crisp white tick.

### Lists & Activity Feeds
Rows within publication feeds are divided by fine 1px dividers (`#334155` at 30%). Hovering rows activates a subtle `#1E293B` slate tint with smooth transition curves (150ms ease-out).

### Approval & Publishing Workflow States
- **Empty States:** Centered slate-800 circular icon container with low-contrast muted vectors, paired with a short Plus Jakarta Sans title, informative body text, and an elevated primary action button ("Create Post").
- **Loading States:** Shimmer skeleton cards using a linear-gradient swipe across `#1E293B` to `#334155` to `#1E293B` at 1.5s intervals.
- **Approval Cards:** Split layout containing content thumbnail preview on the left, copy validation editor in the center, and stacked actions (Approve & Schedule vs. Request Revision) pinned to the right.